<?php
session_start();
include"koneksi.php";
 
$nama = $_POST['nama'];
$tempat_lahir  = $_POST['tempat_lahir'];
$tanggal_lahir =  $_POST['thn'].'-'.$_POST['bln'].'-'.$_POST['tgl'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$alamat = $_POST['alamat'];
$agama = $_POST['agama'];
$status = $_POST['status'];
$kewaganegaraan = $_POST['kewarganegaraan'];



 
$query = "insert INTO masyarakat SET
                                nama = '$nama',
                                tempat_lahir = '$tempat_lahir',
                                tanggal_lahir = '$tanggal_lahir',
                                jenis_kelamin = '$jenis_kelamin',
                                alamat = '$alamat',
                                agama = '$agama',
                                status = '$status',
                                kewarganegaraan =  '$kewarganegaraan'
                                ";
 
mysqli_query($koneksi, $query)
or die ("Gagal Perintah SQL".mysql_error());
$_SESSION['pesan'] = 'Data berhasil di tambahkan';
header('location:taberpetugas.php');
 
?>